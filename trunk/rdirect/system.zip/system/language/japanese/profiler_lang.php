<?php

$lang['profiler_database'] = 'データベース';
$lang['profiler_controller_info'] = 'クラス/メソッド';
$lang['profiler_benchmarks'] = 'ベンチマーク';
$lang['profiler_queries'] = 'クエリ';
$lang['profiler_get_data'] = 'GETデータ';
$lang['profiler_post_data'] = 'POSTデータ';
$lang['profiler_uri_string'] = 'URI文字列';
$lang['profiler_memory_usage'] = 'メモリ使用状況';
$lang['profiler_config'] = '';
$lang['profiler_headers'] = '';
$lang['profiler_no_db'] = 'データベースドライバはロードされていません。';
$lang['profiler_no_queries'] = 'クエリは実行されていません。';
$lang['profiler_no_post'] = 'POSTデータは存在しません。';
$lang['profiler_no_get'] = 'GETデータは存在しません。';
$lang['profiler_no_uri'] = 'URIデータは存在しません。';
$lang['profiler_no_memory'] = 'メモリ使用状況は不明です。';
$lang['profiler_no_profiles'] = '';
?>